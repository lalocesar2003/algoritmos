
package javaapplication42;

import java.util.Arrays;

public class Appcurso {
    public static void main(String[] args) {
        Curso[] cursos = new Curso[5];

        // Crear objetos Curso y almacenarlos en el array desordenado
        cursos[0] = new Curso("C001", 3, "Matemáticas", 4);
        cursos[1] = new Curso("C003", 2, "Historia", 3);
        cursos[2] = new Curso("C002", 4, "Programación", 5);
        cursos[3] = new Curso("C005", 1, "Inglés", 2);
        cursos[4] = new Curso("C004", 3, "Física", 4);

        // Imprimir cursos antes de ordenar
        System.out.println("Cursos antes de ordenar:");
        for (Curso curso : cursos) {
            System.out.println(curso);
        }

        // Ordenar los cursos utilizando QuickSort
        Arrays.sort(cursos);

        // Imprimir cursos después de ordenar
        System.out.println("\nCursos después de ordenar por código:");
        for (Curso curso : cursos) {
            System.out.println(curso);
        }
    }
}
