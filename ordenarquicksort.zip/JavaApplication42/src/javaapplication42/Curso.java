
package javaapplication42;
import java.util.Arrays;
import java.util.Random;

class Curso implements Comparable<Curso> {
    private String codigo;
    private int ciclo;
    private String nombre;
    private int creditos;

    public Curso(String codigo, int ciclo, String nombre, int creditos) {
        this.codigo = codigo;
        this.ciclo = ciclo;
        this.nombre = nombre;
        this.creditos = creditos;
    }

    public String getCodigo() {
        return codigo;
    }

    @Override
    public int compareTo(Curso otroCurso) {
        return this.codigo.compareTo(otroCurso.getCodigo());
    }

    @Override
    public String toString() {
        return "Curso [codigo=" + codigo + ", ciclo=" + ciclo + ", nombre=" + nombre + ", creditos=" + creditos + "]";
    }
}


