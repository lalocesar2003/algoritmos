
package binary.search;

public class BinarySearch {
public static void main(String[] args) {
int[] array = {10, 20, 30, 40, 50, 60, 70, 80};

int key1 = 20;
int key2 = 60;
int key3 = 15;

int index1 = binarySearch(array, key1);
int index2 = binarySearch(array, key2);
int index3 = binarySearch(array, key3);

System.out.println("Index of key " + key1 + ": " + index1);
System.out.println("Index of key " + key2 + ": " + index2);
System.out.println("Index of key " + key3 + ": " + index3);
}

public static int binarySearch(int[] array, int key) {
int left = 0;
int right = array.length - 1;

while (left <= right) {
int mid = left + (right - left) / 2;

if (array[mid] == key) {
return mid;
}

if (array[mid] < key) {
left = mid + 1;
} else {
right = mid - 1;
}
}

return -1; // Key not found
}
}
