
 
package clase2algo;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Objects;

public class cancion implements Comparable<cancion>{
    // Variables de instancia
    private String nombre;
    private String artista;
    private int duracion; // Supondré que la duración está en segundos
    private Genero genero;
    
    private LocalDate lanzamiento;

    @Override
    public int compareTo(cancion o) {
        //throw new UnsupportedOperationException("Not supported yet."); //
        return CANCION_COMPARADOR_NATURAL_ORDER.compare(this, o);
        
    }
    public static final Comparator<cancion> CANCION_COMPARADOR_NATURAL_ORDER = Comparator.comparing(cancion::getNombre).thenComparing(cancion::getArtista).thenComparing(cancion::getDuracion);

    // Enum para el género
    public enum Genero {
        ROCK,
        POP,
        URBANO,
        SALSA
    }

    // Constructor
    public cancion(String nombre, String artista, int duracion, Genero genero, LocalDate lanzamiento) {
        this.nombre = nombre;
        this.artista = artista;
        this.duracion = duracion;
        this.genero = genero;
        this.lanzamiento = lanzamiento;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

      public LocalDate getLanzamiento() {
        return lanzamiento;
    }

    public void setLanzamiento(LocalDate lanzamiento) {
        this.lanzamiento = lanzamiento;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final cancion other = (cancion) obj;
        if (this.duracion != other.duracion) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.artista, other.artista)) {
            return false;
        }
        if (this.genero != other.genero) {
            return false;
        }
        return Objects.equals(this.lanzamiento, other.lanzamiento);
    }
    

    // Método toString para representación de la canción como cadena
    @Override
    public String toString() {
         DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedLanzamiento = lanzamiento.format(formatter);
        
        return "Cancion{" +
                "nombre='" + nombre + '\'' +
                ", artista='" + artista + '\'' +
                ", duracion=" + duracion +
                ", genero=" + genero +
                ", lanzamiento=" + lanzamiento +
                '}';
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        LocalDate fechaLanzamiento = LocalDate.of(1975, 10, 31);
        
        cancion cancion = new cancion("Bohemian Rhapsody", "Queen", 5, Genero.ROCK, fechaLanzamiento);
         cancion cancion2 = new cancion("Bohemian Rhapsody", "Queen", 355, Genero.ROCK, fechaLanzamiento);
        System.out.println(cancion.toString());
       System.out.println("es la cancion 1 igual a la cancion 2 "+cancion.equals(cancion2));
       System.out.println("es la cancion 1 igual a la cancion 2 "+cancion.compareTo(cancion2));
                
                
           
    }
    
}
