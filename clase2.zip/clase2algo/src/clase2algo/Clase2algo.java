/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase2algo;



    class Persona {
    private String nombre;
    private int edad;

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    // Override del método equals para comparar instancias de Persona
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Son la misma instancia
        if (o == null || getClass() != o.getClass()) return false; // Tipos diferentes o null

        Persona persona = (Persona) o; // Conversión segura debido a la comprobación anterior

        // Comparamos nombre y edad
        if (edad != persona.edad) return false;
        return nombre != null ? nombre.equals(persona.nombre) : persona.nombre == null;
    }
}

public class Clase2algo  {
    public static void main(String[] args) {
        Persona persona1 = new Persona("Juan", 25);
        Persona persona2 = new Persona("Juan", 25);
        Persona persona3 = new Persona("María", 30);

        // Comparando las instancias usando equals()
        System.out.println("persona1 es igual a persona2: " + persona1.equals(persona2));
        System.out.println("persona1 es igual a persona3: " + persona1.equals(persona3));
    }
}


