/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto2;

import static proyecto2.SortUTP.mergeSort;
import static proyecto2.SortUTP.quickSort;
import static proyecto2.SortUTP.shellSort;



public class AppAlumno {
    
     public static void main(String[] args) {
        Alumno[] alumnos = {
                new Alumno("Ana", 22, 3),
                new Alumno("Carlos", 20, 2),
                new Alumno("Elena", 21, 4),
                new Alumno("David", 19, 1),
                new Alumno("Berta", 22, 3)
        };

        System.out.println("Alumnos sin ordenar:");
        for (Alumno alumno : alumnos) {
            System.out.println(alumno);
        }

        // Shell Sort
        shellSort(alumnos);
        System.out.println("\nAlumnos ordenados por Shell Sort:");
        for (Alumno alumno : alumnos) {
            System.out.println(alumno);
        }

        // Quick Sort
        quickSort(alumnos);
        System.out.println("\nAlumnos ordenados por Quick Sort:");
        for (Alumno alumno : alumnos) {
            System.out.println(alumno);
        }

        // Merge Sort
        mergeSort(alumnos);
        System.out.println("\nAlumnos ordenados por Merge Sort:");
        for (Alumno alumno : alumnos) {
            System.out.println(alumno);
        }
    }

    
    
}
