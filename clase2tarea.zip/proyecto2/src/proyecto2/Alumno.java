
package proyecto2;
import java.util.Arrays;
import java.util.Comparator;

class Alumno implements Comparable<Alumno> {
    private String nombre;
    private int edad;
    private int ciclo;

    public Alumno(String nombre, int edad, int ciclo) {
        this.nombre = nombre;
        this.edad = edad;
        this.ciclo = ciclo;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public int getCiclo() {
        return ciclo;
    }

    @Override
    public int compareTo(Alumno otroAlumno) {
        int comparacionPorNombre = this.nombre.compareTo(otroAlumno.nombre);
        if (comparacionPorNombre != 0) {
            return comparacionPorNombre;
        }
        return Integer.compare(this.edad, otroAlumno.edad);
    }

    @Override
    public String toString() {
        return "Alumno{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", ciclo=" + ciclo +
                '}';
    }
    
}