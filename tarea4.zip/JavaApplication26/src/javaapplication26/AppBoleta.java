
package javaapplication26;

import java.util.ArrayList;

public class AppBoleta {
     public static void main(String[] args) {
        ArrayList<Producto> datos = new ArrayList<>();
        datos.add(new Producto(1, "Producto 1", 2, 10.0));
        datos.add(new Producto(2, "Producto 2", 3, 15.0));
        datos.add(new Producto(3, "Producto 3", 1, 25.0));

        // Copiar el array datos en otro llamado info
        ArrayList<Producto> info = new ArrayList<>(datos);

        // Generar el reporte ASCII
        System.out.println("Reporte de Boleta\n");
        System.out.println("ID   Nombre          Cantidad   Precio   Total");
        System.out.println("---------------------------------------------");
        for (Producto producto : info) {
            System.out.printf("%-4d %-15s %-10d %-8.2f %-8.2f \n",
                    producto.getId(), producto.getNombre(), producto.getCantidad(),
                    producto.getPrecio(), producto.getTotal());
        }
}
     
}
