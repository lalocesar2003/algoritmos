package Clases;

public class Creacion {
    public static void main(String[] args) {

        // Arrays con inicializadores

        // 1. Crear el array notas de tipo int con 4 notas inicializadas

        // 2. Crear el array alumnos de tipo String con 3 alumnos inicializados

        // 3. Crear el array score de tipo int con 5 valores inicializados

        // 4. Crear el array cantidad de tipo float con 2 valores inicializados desde variables


        // Arrays con new

        // 5. Crear el array devices de tipo String con una capacidad de 5 elementos

        // 6. Crear el array letras de tipo char con una capacidad de 15 elementos

        // 7. Crear el array canciones de tipo Song con una capacidad de 10 elementos

    }
}
