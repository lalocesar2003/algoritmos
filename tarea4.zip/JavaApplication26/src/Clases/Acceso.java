package Clases;

public class Acceso {

    public static void main(String[] args) {

        // Acceso a datos del array

                 // idx =>  0   1   2   3   4   5   6   7   8   9  10
        char[] alfabeto = {'A','E','I','O','U','B','C','T','P','N','M'};

        // 1. Obtener la letra B del array alfabeto
        char letra = 0;
        assert (letra == 'B') : "La letra no es B";
        System.out.println("Ejercicio 1 - OK");

        // 2. Obtener la letra M utilizando como indice el valor de size_alfabeto
        int size_alfabeto = 0;
        letra = 0;
        assert (letra == 'M') : "La letra no es M";
        System.out.println("Ejercicio 2 - OK");

        // 3. Formar la palabra UTP
        char u = 0,t = 0,p = 0;
        u = 0;
        t = 0;
        p = 0;
        System.out.printf("%c%c%c\n",u,t,p);
        assert (u+t+p) == 249 : "No se formo la palabra UTP";
        System.out.println("Ejercicio 3 - OK");

        System.out.println("Programa finalizado correctamente");

    }
}
