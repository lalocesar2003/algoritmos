package Clases;

public class Iteracion {
    public static void main(String[] args) {

        // Iteracion

        String[] ciudades = {"Chiclayo","Piura","Trujillo"};

        // 1. Iterar las ciudades usando fori

        // 2. Iterar las ciudades usando for

        // 3. Copiar los arrays de la clase Creacion e iterarlos

    }
}
