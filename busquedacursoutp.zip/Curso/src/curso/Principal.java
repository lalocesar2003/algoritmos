package curso;

import Utils.SearchUTP;
import Utils.SortUTP;
import Utils.TextUTP;
import java.io.IOException;

public class Principal {

    public static void main(String[] args) throws IOException {
        //Curso[] catalogo={
        //new Curso ("2032",1,"Algoritmos", 2),
        //new Curso ("3328",3,"Sistemas operativos",3),
        //new Curso ("4341",2,"Administracion",2),
        //new Curso ("3246",4,"Individuo",2),
        //new Curso ("1621",4,"Redes",3)};
        
        
        String data[] = TextUTP.readlinesAsArray("C:\\Users\\LAB-USR-PIUR-A307\\Downloads\\Curso\\src\\Utils\\cursos.txt");
        
        int sizeData = data.length;
        Curso catalogo[] = new Curso[sizeData];
        
        for (int i = 0; i < data.length; i++) {
            String linea[] = data[i].split(",");
            String codigo = linea[0];
            int ciclo = Integer.parseInt(linea[1]);
            String nombre = linea[2];
            int creditos = Integer.parseInt(linea[3].replace("\r",""));
            catalogo[i] = new Curso(codigo,ciclo,nombre,creditos);
        }
                
        System.out.println("Data original");
        System.out.println("===================");
        for(Curso item : catalogo){
            System.out.println(item);
        }
        
        SortUTP.quickSort(catalogo);
        
        Curso info = new Curso ("100000N07I");
        
        int idx = SearchUTP.binarySearch(catalogo, info);
        
        if(idx <0) System.out.println("Error valor no encontrado!!!!");
        else { 
            System.out.println("El valor encontrado es:");
            System.out.println(catalogo[idx]);
        }
        //SortUTP.quickSort(catalogo);
        //System.out.println("Data Ordenada");
        //System.out.println("");
        //for(Curso item : catalogo){
            //System.out.println(item);
            
        //}
   //}
 }
}

        

    

