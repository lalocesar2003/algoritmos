package curso;

import java.util.Comparator;
import java.util.Objects;

public class Curso implements Comparable<Curso>{
    
    private String codigo;
    private int ciclo;
    private String nombre;
    private int creditos;

    public Curso(String codigo, int ciclo, String nombre, int creditos) {
        this.codigo = codigo;
        this.ciclo = ciclo;
        this.nombre = nombre;
        this.creditos = creditos;
    }

    public Curso(String codigo) {
        this.codigo = codigo;
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getCiclo() {
        return ciclo;
    }

    public void setCiclo(int ciclo) {
        this.ciclo = ciclo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    @Override
    public String toString() {
        return "Curso{" + "codigo=" + codigo + ", ciclo=" + ciclo + ", nombre=" + nombre + ", creditos=" + creditos + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Curso other = (Curso) obj;
        return Objects.equals(this.codigo, other.codigo);
    }

    @Override
    public int compareTo(Curso o) {
        return CURSO_COMPARATOR_ORDER_NARUTAL.compare(this,o);
    }
    public static final Comparator<Curso> CURSO_COMPARATOR_ORDER_NARUTAL = Comparator.comparing(Curso::getCodigo);
    
    
    }
    
