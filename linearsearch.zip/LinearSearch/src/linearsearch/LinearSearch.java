
package linearsearch;

public class LinearSearch {
public static int linearSearch(int[] arr, int key) {
for (int i = 0; i < arr.length; i++) {
if (arr[i] == key) {
return i; // Retorna la posición donde se encontró la clave
}
}
return -1; // Retorna -1 si la clave no se encontró
}

public static void main(String[] args) {
int[] elements = {100, 25, 61, 98, 205, 18, 2};

int key1 = 205;
int result1 = linearSearch(elements, key1);
if (result1 != -1) {
System.out.println("Clave " + key1 + " encontrada en la posicion " + result1);
} else {
System.out.println("Clave " + key1 + " no encontrada.");
}

int key2 = 61;
int result2 = linearSearch(elements, key2);
if (result2 != -1) {
System.out.println("Clave " + key2 + " encontrada en la posicion " + result2);
} else {
System.out.println("Clave " + key2 + " no encontrada.");
}

int key3 = 15;
int result3 = linearSearch(elements, key3);
if (result3 != -1) {
System.out.println("Clave " + key3 + " encontrada en la posicion " + result3);
} else {
System.out.println("Clave " + key3 + " no encontrada.");
}
}
}
