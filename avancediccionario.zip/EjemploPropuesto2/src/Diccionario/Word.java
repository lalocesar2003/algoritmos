
package Diccionario;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

class Word implements Comparable<Word> {
private String palabra;
private String significado;

public Word(String palabra, String significado) {
this.palabra = palabra;
this.significado = significado;
}

public String getPalabra() {
return palabra;
}

public String getSignificado() {
return significado;
}

@Override
public int compareTo(Word otraPalabra) {
int resultado = this.palabra.compareTo(otraPalabra.palabra);
if (resultado == 0) {
resultado = this.significado.compareTo(otraPalabra.significado);
}
return resultado;
}
}