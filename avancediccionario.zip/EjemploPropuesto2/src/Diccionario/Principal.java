
package Diccionario;

import Utils.TextUTP;
import java.util.ArrayList;
import java.util.Dictionary;

public class Principal {
  public static void main(String[] args) {
      Dictionary dictionary = new Dictionary() {};

// Agregar 10 instancias de Word al diccionario (puedes agregar más)
dictionary.addWord(new Word("apple", "a fruit"));
dictionary.addWord(new Word("banana", "a tropical fruit"));
// Agregar más palabras aquí...

// Ordenar las palabras en el diccionario
dictionary.sortWords();

// Cargar datos desde el archivo oxford.txt utilizando TextUTP
ArrayList<Word> loadedWords = TextUTP.loadDictionaryFromFile("oxford.txt");
for (Word word : loadedWords) {
dictionary.addWord(word);
}

// Realizar una búsqueda en el diccionario
String palabraBuscada = "apple";
Word resultadoBusqueda = dictionary.searchWord(palabraBuscada);
if (resultadoBusqueda != null) {
System.out.println("Palabra encontrada: " + resultadoBusqueda.getPalabra());
System.out.println("Significado: " + resultadoBusqueda.getSignificado());
} else {
System.out.println("Palabra no encontrada.");
}
}
}
  }
}