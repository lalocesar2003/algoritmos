
package Diccionario;

import Utils.TextUTP;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

class Diccionario {
private ArrayList<Word> words;

public Diccionario() {
words = new ArrayList<>();
}

public void addWord(Word word) {
words.add(word);
}

public void sortWords() {
words.sort(Comparator.naturalOrder());
}

public Word searchWord(String target) {
for (Word word : words) {
if (word.getPalabra().equalsIgnoreCase(target)) {
return word;
   }
  }
return null;
 }
}
 public static void main(String[] args) throws IOException {
        //Curso[] catalogo={
        //new Curso ("2032",1,"Algoritmos", 2),
        //new Curso ("3328",3,"Sistemas operativos",3),
        //new Curso ("4341",2,"Administracion",2),
        //new Curso ("3246",4,"Individuo",2),
        //new Curso ("1621",4,"Redes",3)};
        
        
        String data[] = TextUTP.readlinesAsArray("C:\\Users\\LAB-USR-PIUR-A307\\Documents\\NetBeansProjects\\EjemploPropuesto2\\src\\Utils\\oxford.txt");
        
        int sizeData = data.length;
        Curso catalogo[] = new Curso[sizeData];
        
        for (int i = 0; i < data.length; i++) {
            String linea[] = data[i].split(",");
            String codigo = linea[0];
            int ciclo = Integer.parseInt(linea[1]);
            String nombre = linea[2];
            int creditos = Integer.parseInt(linea[3].replace("\r",""));
            catalogo[i] = new Curso(codigo,ciclo,nombre,creditos);
        }
}
